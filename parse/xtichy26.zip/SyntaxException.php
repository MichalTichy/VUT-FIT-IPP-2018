<?php
class SyntaxException extends Exception
{
}