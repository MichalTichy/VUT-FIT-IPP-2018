<?php

class LexicalException extends Exception
{
}