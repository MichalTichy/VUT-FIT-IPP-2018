<?php

interface IValidator
{
    public function Validate($input);

    public function Is($input);
}
