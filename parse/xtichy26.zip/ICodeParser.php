<?php
interface ICodeParser
{
    public function Parse($input);
}